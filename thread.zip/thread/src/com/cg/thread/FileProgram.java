package com.cg.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=null;
		FileInputStream inputStream=null;
		FileOutputStream outputStream=null;
		file=new File("C:\\Users\\varun\\Desktop\\source.txt");
		try {
			inputStream=new FileInputStream(file);
			outputStream=new FileOutputStream("C:\\Users\\varun\\Desktop\\target.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		CopyDataThread thread=new CopyDataThread(file,inputStream,outputStream);
		thread.start();

	}

}
