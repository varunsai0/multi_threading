package com.cg.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
/*class MultiThreading extends Thread{
	
	public void run() {
		File file=null;
		FileInputStream inputStream=null;
		FileOutputStream outputStream=null;
		
		file=new File("C:\\Users\\varun\\Desktop\\source.txt");
		// Thread thread=new c
		try {
			inputStream=new FileInputStream(file);
			outputStream=new FileOutputStream("C:\\Users\\varun\\Desktop\\target.txt");
			int c,count=0;
			while((c=inputStream.read())!=-1) {
				
				System.out.print((char)c);
				outputStream.write((char)c);
				
		   if(c!=0)
				{
				count++;	
				}
		   if(count%10==0) {
			   System.out.println("10 Characters are copied");
			   sleep(5000);
			   
		   }
				
			}
			//System.out.println(count);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}
	
}*/

public class CopyDataThread extends Thread{
	File file=null;
	FileInputStream inputStream=null;
	FileOutputStream outputStream=null;
	public void run() {
		
		
		//file=new File("C:\\Users\\varun\\Desktop\\source.txt");
		// Thread thread=new c
		try {
			//inputStream=new FileInputStream(file);
			//outputStream=new FileOutputStream("C:\\Users\\varun\\Desktop\\target.txt");
			int c,count=0;
			while((c=inputStream.read())!=-1) {
				
				System.out.print((char)c);
				outputStream.write((char)c);
				
		   if(c!=0)
				{
				count++;	
				}
		   if(count%10==0) {
			   System.out.println("10 Characters are copied");
			   sleep(5000);
			   
		   }
				
			}
			//System.out.println(count);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}
	public CopyDataThread() {
		// TODO Auto-generated constructor stub
	}
	

	public CopyDataThread(File file, FileInputStream inputStream, FileOutputStream outputStream) {
		super();
		this.file = file;
		this.inputStream = inputStream;
		this.outputStream = outputStream;
		
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*MultiThreading threading=new MultiThreading();
		threading.start();*/
		
		CopyDataThread dataThread=new CopyDataThread();
		dataThread.start();
		
	}

}
