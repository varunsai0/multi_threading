package com.cg.thread;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimerTaskClass extends TimerTask implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TimerTask task=new TimerTaskClass();
		Timer timer=new Timer(true);
		Runnable runnable=new TimerTaskClass(); 
		Thread thread=new Thread(runnable);
		timer.scheduleAtFixedRate(task, 0, 10*1000);
		try {
			Thread.sleep(100000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*timer.cancel();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("timer task getting refreshed:"+new Date());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
